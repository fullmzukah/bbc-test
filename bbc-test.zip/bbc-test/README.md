BBC web application test
=============

Web application that given a number of pennies will calculate the minimum number of coins needed to make that amount.

## How to run the app

Downloadthe zip file, and open `views/index.html` in a browser (preferably Chrome. Then enter a Sterling amount (e.g. £1.34) and press Enter.

## Web app files and folders 

### `src/`

Contains the Javascript required to:

* **validate.js** - validate the user's input.
* **parse.js** - convert the user's input to an amount of pennies.
* **calculate.js** - calculate the minimum number of coins for a given amount of pennies.
* **input.js** - process events from the user and display/manipulate data within the UI.

### `spec/`

Contains unit tests for the Javascript files using the [Jasmine](http://pivotal.github.io/jasmine/) testing framework.

### `views/`

Contains the single html file required for the UI, including the libraries used Bootstrap,jQuery and the asset(favicon img)



## User Accessibility

I Made sure that the app is screen-reader 'friendly' and that i have tried to incoperate the BBC's core colours




